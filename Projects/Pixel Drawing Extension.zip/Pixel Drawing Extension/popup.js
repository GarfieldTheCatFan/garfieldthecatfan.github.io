document.addEventListener('DOMContentLoaded', function () {
  var canvas = document.getElementById('canvas');
  var ctx = canvas.getContext('2d');
  var pixelSize = 10;

  // Load the drawing from storage (if any)
  loadDrawing();

  canvas.addEventListener('mousedown', function (e) {
    var rect = canvas.getBoundingClientRect();
    var x = Math.floor((e.clientX - rect.left) / pixelSize) * pixelSize;
    var y = Math.floor((e.clientY - rect.top) / pixelSize) * pixelSize;

    if (document.getElementById('bucket-button').classList.contains('active')) {
      var targetColor = ctx.getImageData(x, y, 1, 1).data;
      bucketFill(x, y, targetColor);
    } else {
      drawPixel(x, y);
    }

    canvas.addEventListener('mousemove', drawOnMove);
    canvas.addEventListener('mouseup', removeListeners);
  });

  function drawOnMove(e) {
    var rect = canvas.getBoundingClientRect();
    var x = Math.floor((e.clientX - rect.left) / pixelSize) * pixelSize;
    var y = Math.floor((e.clientY - rect.top) / pixelSize) * pixelSize;

    if (document.getElementById('bucket-button').classList.contains('active')) {
      return; // Ignore drawing when using the bucket fill tool
    }

    drawPixel(x, y);
  }

  function removeListeners() {
    canvas.removeEventListener('mousemove', drawOnMove);
    canvas.removeEventListener('mouseup', removeListeners);

    saveDrawing();
  }

  function drawPixel(x, y) {
    var color = document.getElementById('color-picker').value;
    if (document.getElementById('eraser-button').classList.contains('active')) {
      color = '#FFFFFF'; // White color for eraser
    }
    ctx.fillStyle = color;
    ctx.fillRect(x, y, pixelSize, pixelSize);
  }

  function bucketFill(x, y, targetColor) {
    var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    var pixelsToCheck = [[x, y]];
    var fillColor = document.getElementById('color-picker').value;
    var replacementColor = hexToRgb(fillColor);

    while (pixelsToCheck.length > 0) {
      var currentPixel = pixelsToCheck.pop();
      var px = currentPixel[0];
      var py = currentPixel[1];
      var pixelIndex = (py * canvas.width + px) * 4;
      var currentColor = [
        imageData.data[pixelIndex],
        imageData.data[pixelIndex + 1],
        imageData.data[pixelIndex + 2],
        imageData.data[pixelIndex + 3]
      ];

      if (colorsMatch(currentColor, targetColor) && !colorsMatch(currentColor, replacementColor)) {
        imageData.data[pixelIndex] = replacementColor.r;
        imageData.data[pixelIndex + 1] = replacementColor.g;
        imageData.data[pixelIndex + 2] = replacementColor.b;
        imageData.data[pixelIndex + 3] = 255;

        // Check surrounding pixels
        if (px > 0) {
          pixelsToCheck.push([px - 1, py]);
        }
        if (px < canvas.width - 1) {
          pixelsToCheck.push([px + 1, py]);
        }
        if (py > 0) {
          pixelsToCheck.push([px, py - 1]);
        }
        if (py < canvas.height - 1) {
          pixelsToCheck.push([px, py + 1]);
        }
      }
    }

    ctx.putImageData(imageData, 0, 0);
  }

  function colorsMatch(color1, color2) {
    return (
      color1[0] === color2[0] &&
      color1[1] === color2[1] &&
      color1[2] === color2[2] &&
      color1[3] === color2[3]
    );
  }

  function hexToRgb(hex) {
    var bigint = parseInt(hex.substr(1), 16);
    var r = (bigint >> 16) & 255;
    var g = (bigint >> 8) & 255;
    var b = bigint & 255;
    return { r: r, g: g, b: b };
  }

  function saveDrawing() {
    var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    localStorage.setItem('drawing', JSON.stringify(imageData.data));
  }

  function loadDrawing() {
    var savedDrawing = localStorage.getItem('drawing');
    if (savedDrawing) {
      var imageData = ctx.createImageData(canvas.width, canvas.height);
      imageData.data.set(JSON.parse(savedDrawing));
      ctx.putImageData(imageData, 0, 0);
    }
  }

  function clearDrawing() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    localStorage.removeItem('drawing');
  }

  function saveImage() {
    var link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    link.download = 'drawing.png';
    link.click();
  }

  function loadImage() {
    var fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/png';

    fileInput.addEventListener('change', function () {
      var file = fileInput.files[0];
      var reader = new FileReader();

      reader.onload = function (event) {
        var image = new Image();
        image.onload = function () {
          ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
          saveDrawing();
        };
        image.src = event.target.result;
      };

      reader.readAsDataURL(file);
    });

    fileInput.click();
  }

  document.getElementById('eraser-button').addEventListener('click', function () {
    this.classList.toggle('active');
    document.getElementById('bucket-button').classList.remove('active');
  });

  document.getElementById('bucket-button').addEventListener('click', function () {
    this.classList.toggle('active');
    document.getElementById('eraser-button').classList.remove('active');
  });

  document.getElementById('clear-button').addEventListener('click', clearDrawing);

  document.getElementById('save-button').addEventListener('click', saveImage);

  document.getElementById('load-button').addEventListener('click', loadImage);

  document.getElementById('more-button').addEventListener('click', function () {
    document.getElementById('more-menu').classList.toggle('show');
  });

  document.getElementById('more-extensions').addEventListener('click', function () {
    window.open('https://garfieldthecatfan.github.io');
  });
});
